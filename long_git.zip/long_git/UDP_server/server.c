#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>

#define PORT 12345
#define BUFFER_SIZE 1024
#define FILE_BUFFER_SIZE 4096

static void setup_socket(int *sockfd) 
{
    *sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (-1 == *sockfd) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
}

static void bind_socket(int sockfd) 
{
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    int binded = bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (-1 == binded) {
        perror("Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
}

static void handle_file_transfer(int sockfd, struct sockaddr_in *client_addr, char *filename, char *buffer, int is_send) 
{
    FILE *fp = NULL;
    ssize_t bytes_received = 0;
    int n = 0;

    if (is_send) {
        fp = fopen(filename, "rb");
        if (fp == NULL) {
            perror("File open failed");
            return;
        }

        do {
            n = fread(buffer, 1, FILE_BUFFER_SIZE, fp);
            sendto(sockfd, buffer, n, 0, (const struct sockaddr *)client_addr, sizeof(*client_addr));
        } while (n == FILE_BUFFER_SIZE);

        fclose(fp);
        printf("File sent: %s\n", filename);
    }
    else {
        fp = fopen(filename, "wb");
        if (fp == NULL) {
            perror("File open failed");
            return;
        }

        int len = sizeof(*client_addr);
        do {
            bytes_received = recvfrom(sockfd, buffer, FILE_BUFFER_SIZE, 0, (struct sockaddr *)client_addr, &len);

            if (bytes_received > 0) {
                fwrite(buffer, 1, bytes_received, fp);
            }
            
        } while (FILE_BUFFER_SIZE == bytes_received);

        fclose(fp);
        printf("File received: %s\n", filename);
    }
}

static void handle_message(int sockfd, struct sockaddr_in *client_addr, char *buffer) 
{
    int cmp = strncmp(buffer, "FILE:", 5);
    if (0 == cmp) {
        char filename[BUFFER_SIZE] = {0};
        strncpy(filename, buffer + 5, sizeof(filename) - 1);
        printf("开始接收文件，接收中...\n");
        handle_file_transfer(sockfd, client_addr, filename, buffer, 0);
    }
    else {
        printf("Received message: %s\n", buffer);
    }
}

int main(void) 
{
    int sockfd = 0;
    struct sockaddr_in server_addr = {0};
    struct sockaddr_in client_addr = {0};
    socklen_t addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE] = {0};
    char file_buffer[FILE_BUFFER_SIZE] = {0};
    fd_set readfds;
    struct timeval timeout = {0};

    setup_socket(&sockfd);
    bind_socket(sockfd);

    while (1) {
        FD_ZERO(&readfds); // 清空文件描述符集
        FD_SET(STDIN_FILENO, &readfds); // 添加标准输入
        FD_SET(sockfd, &readfds); // 添加UDP套接字

        // 设置超时时间
        timeout.tv_sec = 5;
        timeout.tv_usec = 0;

        // 使用select进行多路复用
        int selected = select(sockfd + 1, &readfds, NULL, NULL, &timeout);
        if (-1 == selected) {
            perror("Select failed");
            continue;
        }

        if (FD_ISSET(sockfd, &readfds)) { // 如果套接字可读
            ssize_t bytes_received = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
            if (bytes_received == -1) {
                perror("Recvfrom failed");
                continue;
            }
            buffer[bytes_received] = '\0'; // 确保字符串终止
            handle_message(sockfd, &client_addr, buffer);
        }

        if (FD_ISSET(STDIN_FILENO, &readfds)) { // 如果标准输入可读
            fgets(buffer, BUFFER_SIZE, stdin);
            int len = strlen(buffer);
            buffer[len - 1] = '\0';
            int cmp = strncmp(buffer, "FILE:", 5);
            if (0 == cmp) {
                sendto(sockfd, buffer, strlen(buffer), 0, (const struct sockaddr *)&client_addr, addr_len);
                handle_file_transfer(sockfd, &client_addr, buffer + 5, file_buffer, 1);
            }
            else {
                sendto(sockfd, buffer, strlen(buffer), 0, (const struct sockaddr *)&client_addr, addr_len);
                printf("Message sent: %s\n", buffer);
            }
        }
    }

    close(sockfd);
    return 0;
}