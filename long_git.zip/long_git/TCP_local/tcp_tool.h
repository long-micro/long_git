#include <arpa/inet.h>
#include <errno.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>

struct ip_msg {
	char *addr_src;
	char *addr_dst;
	int port_src;
	int port_dst;
};

static inline uint8_t get_protocol_type(uint8_t *packet)
{
    struct iphdr *iphead_tmp = (struct iphdr *)packet;
    return iphead_tmp->protocol;
}

static inline uint8_t get_ctl_type(uint8_t *packet)
{
    struct tcphdr *tcphead_tmp = (struct tcphdr *)(packet + sizeof(struct iphdr));
    return tcphead_tmp->th_flags & 0x3F;
}

static inline uint32_t get_seq(uint8_t *packet)
{   
    struct tcphdr *tcphead_tmp = (struct tcphdr *)(packet + sizeof(struct iphdr));
    return ntohl(tcphead_tmp->seq);
}

void iphead_init(struct iphdr *iphead, struct ip_msg ip_msg);

void tcphd_init(struct tcphdr *tcphead, struct ip_msg ip_msg);

bool judge_ctl_type(uint8_t *recv_packet, const uint8_t ctl_type);

int init_ctl_type(struct tcphdr *tcphead, uint8_t *recv_packet, const char *ctl_type);

int socket_init(struct ip_msg ip_msg);

void communicate_init(struct sockaddr_in *recv_addr, struct ip_msg ip_msg, struct iphdr *iphead, struct tcphdr *tcphead);