#include "tcp_tool.h"

int main(int argc, char *argv[])
{
    if (argc != 5) {
        printf("输入参数格式错误，请依次输入：发送端ip、发送端port、接收端ip、接收端port\n");
        return -1;
    }

    int sockfd = 0;
    uint8_t send_packet[1024] = {0};
    uint8_t recv_packet[1024] = {0};
    struct iphdr *iphead = (struct iphdr *)send_packet;
    struct tcphdr *tcphead = (struct tcphdr *)(send_packet + sizeof(struct iphdr));
    struct sockaddr_in dst_addr = {0};

	struct ip_msg ip_msg = {argv[1], argv[2], atoi(argv[3]), atoi(argv[4])};

	sockfd = socket_init(ip_msg);

	communicate_init(&dst_addr, ip_msg, iphead, tcphead);

	for (bool checked = judge_ctl_type(recv_packet, TH_SYN); true != checked; checked = judge_ctl_type(recv_packet, TH_SYN)) {
		ssize_t recved = recvfrom(sockfd, recv_packet, iphead->tot_len, 0, NULL, NULL);
        if (recved < 0) {
            (void)close(sockfd);
            printf("send error, err(%d:%s)\n", errno, strerror(errno));
            return -1;
        }	
	}
	
	init_ctl_type(tcphead, recv_packet, "syn_ack");
	ssize_t sended_syn_ack = sendto(sockfd, send_packet, iphead->tot_len, 0, (struct sockaddr *)&dst_addr, sizeof(dst_addr));
    if (sended_syn_ack < 0) {
        (void)close(sockfd);
        printf("send error, err(%d:%s)\n", errno, strerror(errno));
        return -1;
    }

    (void)close(sockfd);

	return 0;
}
