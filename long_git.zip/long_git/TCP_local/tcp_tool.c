#include "tcp_tool.h"

void iphead_init(struct iphdr *iphead, struct ip_msg ip_msg)
{
	iphead->version = 4;
	iphead->ihl = 5;
	iphead->tos = 0;
    iphead->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr);
    iphead->id = htons(1234);
    iphead->frag_off = 0;//偏移，以8字节为单位偏移
    iphead->ttl = 64;
    iphead->protocol = IPPROTO_TCP;
    iphead->saddr = inet_addr(ip_msg.addr_src);
    iphead->daddr = inet_addr(ip_msg.addr_dst);
    iphead->check = 0;
}

void tcphd_init(struct tcphdr *tcphead, struct ip_msg ip_msg)
{
	tcphead->source = htons(ip_msg.port_src);
	tcphead->dest = htons(ip_msg.port_dst);
	tcphead->seq = htonl(0);
	tcphead->ack_seq = htonl(0);
	tcphead->doff = sizeof(struct tcphdr) / 4;
	tcphead->window = htons(4096);
    tcphead->check = 0;
}

bool judge_ctl_type(uint8_t *recv_packet, const uint8_t ctl_type)
{
	uint8_t protocol_type = get_protocol_type(recv_packet);
	if (IPPROTO_TCP == protocol_type) {
		uint8_t recv_ctl_type = get_ctl_type(recv_packet);
        if (ctl_type == recv_ctl_type) {
            return true;
        }
	}

	return false;
}

int init_ctl_type(struct tcphdr *tcphead, uint8_t *recv_packet, const char *ctl_type)
{	
	uint32_t recv_seq = get_seq(recv_packet);

    tcphead->fin = 0;
    tcphead->rst = 0;
    tcphead->psh = 0;
    tcphead->urg = 0;
 
    int is_syn = strcmp("syn", ctl_type);
    int is_syn_ack = strcmp("syn_ack", ctl_type);
    int is_ack = strcmp("ack", ctl_type);

    if (0 == is_syn) {
        tcphead->syn = 1;
        tcphead->ack = 0; 
        tcphead->seq = htonl(0);
        tcphead->ack_seq= htonl(0);
    }
    else if (0 == is_syn_ack) {
        tcphead->syn = 1;
        tcphead->ack = 1;
        tcphead->seq = htonl(0);
        tcphead->ack_seq= htonl(recv_seq + 1);
    }
    else if (0 == is_ack) {
        tcphead->syn = 0;
        tcphead->ack = 1;
        tcphead->seq = htonl(1);
        tcphead->ack_seq= htonl(recv_seq + 1);
    }
    else {
        printf("错误的初始化标志位\n");
        return -1;
    }

    return 0;
}

int socket_init(struct ip_msg ip_msg)
{
	int sockfd = 0;
	struct sockaddr_in src_addr = {0};

	src_addr.sin_family = AF_INET;
	src_addr.sin_addr.s_addr = inet_addr(ip_msg.addr_src);
	src_addr.sin_port = htons(ip_msg.port_src);

    sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sockfd < 0) {
        printf("socket error, err(%d:%s)\n", errno, strerror(errno));
        return -1;
    }

    int optval = 1;
    int seted = setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &optval, sizeof(optval));
    if (seted < 0) {
        (void)close(sockfd);
        printf("setsockopt error, err(%d:%s)\n", errno, strerror(errno));
        return -1;
    }

    socklen_t addr_len = sizeof(struct sockaddr_in);
	int binded = bind(sockfd, (struct sockaddr *)&src_addr, addr_len);
	if (binded < 0) {
        (void)close(sockfd);
        printf("bind error, err(%d:%s)\n", errno, strerror(errno));
        return -1;
    }

    return sockfd;
}

void communicate_init(struct sockaddr_in *dst_addr, struct ip_msg ip_msg, struct iphdr *iphead, struct tcphdr *tcphead)
{
	dst_addr->sin_family = AF_INET;
	dst_addr->sin_addr.s_addr = inet_addr(ip_msg.addr_dst);
	dst_addr->sin_port = htons(ip_msg.port_dst);	

	iphead_init(iphead, ip_msg);
    tcphd_init(tcphead, ip_msg);
}
